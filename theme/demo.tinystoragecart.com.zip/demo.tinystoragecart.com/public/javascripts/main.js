(function(requirejs) {
'use strict';

var requireJsBasePath = window.requireJsBasePath || 'public/javascripts';
var $productProperties = document.querySelectorAll('.productproperty');
var $addToCart = document.querySelectorAll('.addtocart');
var $ordercartlist = document.querySelector('#ordercartlist');
var $checkoutform = document.querySelector('#checkoutform');
var $singleShipping = document.querySelector('[data-shippingcost]');
var $singlePackaging = document.querySelector('[data-packagingsize]');
var $cartcheckoutshippingskeleton =
    document.querySelector('[data-cartcheckoutshippingskeleton]');

// require configuration
requirejs.config({
  urlArgs: '1565045841',
  baseUrl: requireJsBasePath,
  paths: {async: 'vendor/async', serialize: 'vendor/serialize'},
  shim: {'cart/sendform': ['serialize']}
});

/**
 * Start - add properties to cart
 */
function addPropertiesEvent($el) {
  requirejs(['cart/cart'], function(cart) {
    $el.addEventListener('change', function(element) {
      var $el = element.target;
      var propertyName = $el.dataset.productproperty;
      var property = '';

      if ($el.tagName === 'INPUT' && $el.type === 'checkbox' && $el.checked) {
        property = $el.getAttribute('name');
      }

      if ($el.tagName === 'INPUT' && $el.type === 'radio' && $el.checked) {
        property = 'true';
      }

      if ($el.tagName === 'SELECT') {
        property = $el.options[$el.selectedIndex].value;
      }

      if ($el.type === 'radio') {
        // set the last parameter to reset the properties
        cart.addPropertiesToProductData(propertyName, property, true);
      } else {
        cart.addPropertiesToProductData(propertyName, property);
      }
    });
  });
}

if ($productProperties.length > 0) {
  for (var i = 0; i < $productProperties.length; i++) {
    var $el = $productProperties[i];
    addPropertiesEvent($el);
  }
}
/**
 * End - add properties to cart
 */

if ($addToCart.length > 0) {
  requirejs(['cart/cart'], function(cart) {
    for (var i = 0, len = $addToCart.length; i < len; i++) {
      $addToCart[i].onclick = function() {
        cart.triggerAddToCart(this);
      };
    }
  });
}

if ($ordercartlist) {
  requirejs(['cart/checkout']);
}

if ($checkoutform) {
  requirejs(['cart/sendform']);
}

/**
 * Headerbar
 */

// Display Headerbar when products in cart
var updateHeaderBar = function() {
  var localData = JSON.parse(localStorage.getItem('cartStorage'));
  if (localData && !$ordercartlist) {
    requirejs(['cart/headerBar'], function(headerBar) {
      var headerbarData = headerBar.getHeaderbar();
      headerBar.updateHeaderBarQty(headerbarData);
      headerBar.displayHeaderBar();
    });
  }
};

updateHeaderBar();
document.addEventListener('addItemToCart', updateHeaderBar);

document.addEventListener('addItemToCart', function(e) {
  requirejs(['cart/cart'], function(notification) {
    notification.displayNotification(e.detail.qty, e.detail.product.name);
  });

  /**
   * Add item on on checkout page
   */
  if ($ordercartlist) {
    requirejs(['cart/checkout'], function(checkout) {
      // delete DOMelements
      document.querySelectorAll('[data-productlistid]')
          .forEach(function(element) {
            element.remove();
          });
      checkout.calculateCart();
    });
  }
});

/**
 * calculate shipping
 */
if ($singleShipping && $singlePackaging && $cartcheckoutshippingskeleton) {
  document.addEventListener('calculateCartSum', function(e) {
    requirejs(['cart/cart'], function(cart) {
      var singleShippingPrice = $singleShipping.dataset.shippingcost;
      var singlePackagingSize = $singlePackaging.dataset.packagingsize;
      var totalProducts = cart.checkCartQty();
      var totalPackages = Math.ceil(totalProducts / singlePackagingSize);
      var shippingCost =
          parseFloat(totalPackages * singleShippingPrice).toFixed(2);
      var fullprice = 0;

      var cartTotal = e.detail.cartTotal;
      if (cart.checkDecimalmark()) {
        cartTotal = cart.commaToPoint(cartTotal);
        fullprice = cart.pointToComma((shippingCost + cartTotal));
      } else {
        shippingCost = parseFloat(shippingCost);
        cartTotal = parseFloat(cartTotal);
        fullprice = (shippingCost + cartTotal);
      }

      if (cart.checkDecimalmark()) {
        shippingCost = cart.pointToComma(shippingCost);
      }

      cart.searchDataAndReplace(
          document, 'cartcheckoutsumpriceskeleton', '{sumprice}',
          cart.calculateTotal());
      cart.searchDataAndReplace(
          document, 'cartcheckoutshippingskeleton', '{shippingprice}',
          shippingCost.toFixed(2));
      cart.searchDataAndReplace(
          document, 'cartcheckoutfullskeleton', '{fullprice}',
          fullprice.toFixed(2));
    });
  });
}
})(requirejs);
