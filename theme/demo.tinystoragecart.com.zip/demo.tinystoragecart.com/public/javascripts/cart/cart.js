define(function() {
  'use strict';
  return function() {
    if ('function' == typeof window.CustomEvent) return;
    function t(t, e) {
      e = e || {bubbles: !1, cancelable: !1, detail: void 0};
      var r = document.createEvent('CustomEvent');
      return r.initCustomEvent(t, e.bubbles, e.cancelable, e.detail), r
    }
    t.prototype = window.Event.prototype, window.CustomEvent = t
  }(),
         [
           Element.prototype, CharacterData.prototype, DocumentType.prototype
         ].forEach(function(t) {
           t.hasOwnProperty('remove') || Object.defineProperty(t, 'remove', {
             configurable: !0,
             enumerable: !0,
             writable: !0,
             value: function() {
               null !== this.parentNode && this.parentNode.removeChild(this)
             }
           })
         }),
  {
    hashCode: function(t) {
      var e = 0;
      if (0 === t.length) return e;
      for (var r = 0; r < t.length; r++) {
        e = (e << 5) - e + t.charCodeAt(r), e &= e
      }
      return e
    }, getProductData: function(t) {
      var e = [];
      return e.id = t.dataset.productid, e.image = t.dataset.productimage,
             e.name = t.dataset.productname, e.price = t.dataset.productprice,
             e.data = t.dataset.productdata,
             e.properties = t.dataset.productproperties, e
    }, searchDataAndReplace: function(t, e, r, a, o) {
      var n = t.querySelector('[data-' + e + ']');
      if (n) {
        var i = n.dataset[e];
        o ? n.outerHTML = 'all' === r ? a : i.replace(r, a) :
            n.innerHTML = i.replace(r, a)
      }
    }, checkDecimalmark: function() {
      var t = document.querySelector('[data-decimalmark]');
      if (t && ',' === t.dataset.decimalmark) return !0;
      return !1
    }, commaToPoint: function(t) {
      return parseFloat(t.replace(',', '.'))
    }, pointToComma: function(t) {
      return t.toString().replace('.', ',')
    }, addClass: function(t, e) {
      t.classList ? t.classList.add(e) : t.className += ' ' + e
    }, displayNotification: function(t, e) {
      var r = document.querySelector('#notificationskeleton'),
          a = document.querySelector('#notificationwrap'),
          o = r.querySelector('.notification__text')
                  .dataset.notificationmessage;
      o = (o = o.replace('{qty}', t)).replace('{productname}', e);
      var n = r.cloneNode(!0);
      n.removeAttribute('id'),
          n.className = 'notification',
          n.querySelector('.notification__text').innerHTML = o, a.appendChild(n)
    }, findIndexByKeyValue: function(t, e, r) {
      for (var a = this.getStorageCart(), o = [], n = 0; n < t.length; n++)
        t[n] && t[n][e] == r.id && o.push(n);
      if (0 < o.length) {
        if (1 === o.length)
          return this.checkProductProperties(r, a[o[0]]) ? o[0] : null;
        for (var i = 0; i < o.length; i++)
          if (this.checkProductProperties(r, a[o[i]])) return o[i];
        return null
      }
      return null
    }, getStorageCart: function() {
      var t, e = JSON.parse(localStorage.getItem('cartStorage'));
      return t = 'null' !== e && e ? e : [], e = this.filterArray(t),
             localStorage.clear(),
             localStorage.setItem('cartStorage', JSON.stringify(e)), e
    }, filterArray: function(t) {
      return t.filter(function(t) {
        return null != t
      })
    }, checkCartQty: function() {
      for (var t = this.getStorageCart(), e = 0, r = 0, a = t.length; r < a;
           r++)
        void 0 !== t[r] && null !== t[r] && (e += parseInt(t[r].qty));
      return 0 === e && localStorage.clear(), e
    }, setAttributes: function(t, e) {
      for (var r in e) e.hasOwnProperty(r) && t.setAttribute(r, e[r])
    }, addToStorage: function(t, e, r) {
      var a = this.getStorageCart(), o = e,
          n = this.findIndexByKeyValue(a, 'id', t);
      null != n &&
          (o = r ? parseInt(e) : parseInt(a[n].qty) + parseInt(e), delete a[n]);
      var i = {
        id: t.id,
        image: t.image,
        name: t.name,
        price: t.price,
        calcprice: t.price,
        data: t.data,
        properties: t.properties,
        propertieshash: this.hashCode(t.properties),
        qty: o
      };
      document.dispatchEvent(
          new CustomEvent('addItemToStorage', {detail: {product: i}})),
          a.push(i), a = this.filterArray(a),
                     localStorage.setItem('cartStorage', JSON.stringify(a))
    }, deleteFromStorage: function(e, r) {
      var t = this.getStorageCart();
      t = t.filter(function(t) {
        return t.id !== e ? t.id !== e :
                            t.properties !== r ? t.properties !== r : void 0
      }),
      localStorage.setItem('cartStorage', JSON.stringify(t))
    }, triggerAddToCart: function(t) {
      var e = this.getProductData(t), r = 1;
      document.querySelector('#qtyadd') &&
          (r = document.querySelector('#qtyadd').value),
          this.addToStorage(e, r),
          document.dispatchEvent(
              new CustomEvent('addItemToCart', {detail: {product: e, qty: r}}))
    }, checkProductProperties: function(t, e) {
      return this.hashCode(t.properties) === e.propertieshash
    }, addPropertiesToProductData: function(t, e, r) {
      var a = document.getElementById('addtocart'),
          o = a.getAttribute('data-productproperties');
      o = !o || r ? {} : JSON.parse(o), e ? o[t] = e : delete o[t];
      var n = {};
      Object.keys(o).sort().forEach(function(t) {
        n[t] = o[t]
      }),
          a.setAttribute('data-productproperties', JSON.stringify(n))
    }, calculateTotal: function() {
      for (var t = this.getStorageCart(), e = 0, r = 0, a = t.length; r < a;
           r++) {
        e += this.commaToPoint(t[r].calcprice) * t[r].qty
      }
      return e = e.toFixed(2),
             this.checkDecimalmark() && (e = this.pointToComma(e)), e
    }
  }
});