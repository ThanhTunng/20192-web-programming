define(['cart/cart'], function(r) {
  'use strict';
  return {
    getHeaderbar: function() {
      var e = [];
      return e.headerbarElement = document.querySelector('#headerbar'),
             e.headerbarContentElement =
                 e.headerbarElement.querySelector('.headerbar__content'),
             e.headerbartext =
                 e.headerbarContentElement.dataset.headerbarcontent,
             e
    }, addHeaderBarContent: function(e, r, a) {
      e.headerbarElement.querySelector('.headerbar__content').innerHTML =
          r + ' x ' + a.name + e.headerbartext
    }, displayHeaderBar: function() {
      document.querySelector('#pageheader')
          .classList.add('pageheader--opencart')
    }, updateHeaderBarQty: function(e) {
      e.headerbarElement.querySelector('.headerbar__notificationcount')
          .innerHTML = r.checkCartQty()
    }
  }
});