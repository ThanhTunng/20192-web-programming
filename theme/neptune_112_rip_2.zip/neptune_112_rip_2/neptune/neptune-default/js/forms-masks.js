$(document).ready(function() {

	$('.autonumber').autoNumeric('init');
	
});